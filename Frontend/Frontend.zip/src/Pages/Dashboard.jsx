import React, { useEffect, useState } from 'react'
import { decodeToken } from '../utils/decodeToken';
import DashBoardCard from '../Components/dashboard/DashBoardCard';
import { Link, useNavigate } from 'react-router-dom';
import Logo from '../Components/Logo';
import Search from '../Components/Search';
import DashBoardTable from '../Components/dashboard/DashBoardTable';
import axiosInstance from '../Helper/axiosInstance';
import toast from 'react-hot-toast';
import Cookies from 'js-cookie';
import DashBoardUploadVideoModal from '../Components/dashboard/DashBoardUploadVideoModal';
import DashBoardUploadingVideo from '../Components/dashboard/DashBoardUploadingVideo';
import DashBoardEditVideo from '../Components/dashboard/DashBoardEditVideo';
import HomeLayout from '../Layout/HomeLayout';
import DashboardSkeleton from '../Components/DashboardSkeleton';
import ServerError from './ServerError';

function Dashboard() {
    const navigate = useNavigate();
    const token = decodeToken();
    const fullName = token?.fullName;
    const username = token?.username;

    const [channelVideos, setChannelVideos] = useState({});
    const [channelStats, setChannelStats] = useState([]);
    const [isChannelLoading, setIsChannelLoading] = useState(true);
    const [isError, setIsError] = useState(false);
    const [isToggling, setIsToggling] = useState(false);
    const [toggleModal, setToggleModal] = useState(false);
    const [uploadingVideo, setUploadingVideo] = useState(false);
    const [videoName, setVideoName] = useState('');
    const [videoSize, setVideoSize] = useState('');
    const [uploaded, setUploaded] = useState(false);
    const [editVideo, setEditVideo] = useState(false);
    const [editVideoId, setEditVideoId] = useState('');
    const [editVideoData, setEditVideoData] = useState({});

    const handleLogout = async () => {
        try {
          let res = await axiosInstance.post("/users/logout");
          if (res.data) {
            localStorage.clear();
            Cookies.remove('session-auth-access');
            Cookies.remove('session-auth-refreshToken');
            navigate("/login")
          }
        } catch (error) {
          console.log(error);
        }
    }

    const fetchChannelVideos = async () => {
        try {
            const resStats = await axiosInstance.get("/dashboard/stats");
            const resVideos = await axiosInstance.get("/dashboard/videos");
            if (resStats && resVideos) {
                setChannelStats(resStats.data.data);
                setChannelVideos(resVideos.data.data);
            }
        } catch (error) {
            console.log(error);
            setIsError(true);
        } finally {
            setIsChannelLoading(false);
        }
    }

    useEffect(() => {
        fetchChannelVideos();
    }, []);

    if (isChannelLoading) {
        return (
            <DashboardSkeleton />
        )
    }

    if (isError) {
        return (
            <HomeLayout>
                <ServerError />
            </HomeLayout>
        )
    }

    const handleCheckboxToggle = async(videoId) => {
        try {
            setIsToggling(true);
            const res = await axiosInstance.patch(`/videos/toggle/publish/${videoId}`, { videoId });
            console.log(res);
            if (res.data.statusCode==200) {
                fetchChannelVideos();
                toast.success(res.data.data.isPublished? "Video published successfully" : "Video unpublished successfully");
            }
        } catch (error) {
            console.log(error);
            toast.error("Something went wrong! Please try again later");
        } finally {
            setIsToggling(false);
        }
    };
    
    const handleDeleteClick = async (videoId) => {
        try {
            setIsToggling(true);
            toast.loading("Deleting video...");
            const res = await axiosInstance.delete(`/videos/${videoId}`, { videoId });
            if (res.data.statusCode==200) {
                fetchChannelVideos();
                toast.success("Video deleted successfully");
            }
        } catch (error) {
            console.log(error);
            toast.error("Something went wrong! Please try again later");
        } finally {
            setIsToggling(false);
        }
    };

    const handleToggleModal = () => {
        setToggleModal(true);
    };

    const handleCloseModal = () => {
        setToggleModal(false);
    }

    const handleCloseVideo = () => {
        setUploadingVideo(false);
        setUploaded(false);
    }

    const handleUploadVideo = async (videoData, name, videoSize) => {
        try {
            setToggleModal(false);
            setUploadingVideo(true)
            setVideoName(name);
            setVideoSize(videoSize);
            const res = await axiosInstance.post("/videos", videoData);
            if (res.data.statusCode==200) {
                setUploaded(true);
                setUploadingVideo(false);
                setVideoName('');
                fetchChannelVideos();
                toast.success("Video uploaded successfully");
            }
        } catch (error) {
            setUploadingVideo(false);
            setToggleModal(false);
            setVideoName('');
            setVideoSize('');
            console.log(error);
            toast.error("Something went wrong! Please try again later");
        }
    }

    const handleEditVideo = async (videoId, title, thumbnail, description) => {
        setEditVideo(true);
        setEditVideoId(videoId);
        const data = {
            videoId: videoId,
            title: title,
            thumbnail: thumbnail,
            description: description,
        }
        setEditVideoData(data);
    }

    const handleEditVideoClose = () => {
        setEditVideo(false);
        setEditVideoId('');
        setEditVideoData({});
    }

    const handleSubmitEditVideo = async (videoData) => {
        try {
            setEditVideo(true);
            const res = await axiosInstance.patch(`/videos/${editVideoId}`, videoData);
            if (res.data.statusCode==200) {
                setEditVideo(false);
                setEditVideoId('');
                fetchChannelVideos();
                toast.success("Video updated successfully");
            }
        } catch (error) {
            setEditVideo(false);
            setEditVideoId('');
            console.log(error);
            toast.error("Something went wrong! Please try again later");
        }
    }

    return (
        <>
            <header className="sticky inset-x-0 top-0 z-50 w-full border-b border-white bg-[#121212] px-4">
                <nav className="mx-auto flex max-w-7xl items-center py-2">
                <Link to={"/"}>
                    <div className="flex items-center space-x-2">
                    <div className="shrink-0">
                        <Logo />
                    </div>
                    <h3 className="uppercase font-bold text-xl text-white">Youtube</h3>
                    </div>
                </Link>
                <Search />
                <button className="ml-auto sm:hidden">
                    <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth="1.5"
                    stroke="currentColor"
                    aria-hidden="true"
                    className=" h-6 w-6"
                    >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"
                    />
                    </svg>
                </button>
                <button className="group peer ml-4 flex w-6 shrink-0 flex-wrap gap-y-1.5 sm:hidden">
                    <span className="block h-[2px] w-full bg-white group-hover:bg-[#ae7aff]" />
                    <span className="block h-[2px] w-2/3 bg-white group-hover:bg-[#ae7aff]" />
                    <span className="block h-[2px] w-full bg-white group-hover:bg-[#ae7aff]" />
                </button>
                <div className="fixed inset-y-0 right-0 flex w-full max-w-xs shrink-0 translate-x-full flex-col border-l border-white bg-[#121212] duration-200 hover:translate-x-0 peer-focus:translate-x-0 sm:static sm:ml-4 sm:w-auto sm:translate-x-0 sm:border-none">
                    <div className="relative flex w-full items-center justify-between border-b border-white px-4 py-2 sm:hidden">
                    <span className="inline-block w-12">
                        <svg
                        style={{ width: "100%" }}
                        viewBox="0 0 63 64"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        >
                        <path
                            d="M47.25 47.458C55.9485 38.7595 55.9485 24.6565 47.25 15.958C38.5515 7.25952 24.4485 7.25952 15.75 15.958C7.05151 24.6565 7.05151 38.7595 15.75 47.458C24.4485 56.1565 38.5515 56.1565 47.25 47.458Z"
                            stroke="#E9FCFF"
                            strokeWidth="1.38962"
                            strokeMiterlimit={10}
                        />
                        <path
                            d="M10.5366 47.7971V17.5057C10.5366 16.9599 11.1511 16.6391 11.599 16.9495L33.4166 32.0952C33.8041 32.3639 33.8041 32.9368 33.4166 33.2076L11.599 48.3533C11.1511 48.6657 10.5366 48.3429 10.5366 47.7971Z"
                            stroke="url(#paint0_linear_53_10115)"
                            strokeWidth="6.99574"
                            strokeMiterlimit={10}
                            strokeLinecap="round"
                        />
                        <path
                            d="M18.1915 27.6963C20.1641 27.6963 21.7285 28.7066 21.7285 30.9021C21.7285 33.0976 20.1621 34.2433 18.1915 34.2433H16.8854V37.8677H14.1733V27.6984H18.1915V27.6963Z"
                            fill="#E9FCFF"
                        />
                        <path
                            d="M25.2053 27.6963V35.4868H28.484V37.8657H22.4932V27.6963H25.2053Z"
                            fill="#E9FCFF"
                        />
                        <path
                            d="M35.3142 27.6963L39.4553 37.8657H36.5328L35.9162 36.1763H32.1939L31.5773 37.8657H28.6548L32.7959 27.6963H35.3101H35.3142ZM34.9143 33.5663L34.2144 31.7832C34.1582 31.6395 33.954 31.6395 33.8978 31.7832L33.1979 33.5663C33.1541 33.6767 33.2354 33.7975 33.3562 33.7975H34.756C34.8747 33.7975 34.958 33.6767 34.9143 33.5663Z"
                            fill="#E9FCFF"
                        />
                        <path
                            d="M40.9491 27.6963L42.8592 30.5188L44.7694 27.6963H48.0355L44.2132 33.2559V37.8657H41.5011V33.2559L37.6787 27.6963H40.9449H40.9491Z"
                            fill="#E9FCFF"
                        />
                        <path
                            d="M16.894 32.1396V29.9129C16.894 29.8212 16.9982 29.7671 17.0732 29.8191L18.6771 30.9315C18.7417 30.9773 18.7417 31.0731 18.6771 31.1189L17.0732 32.2313C16.9982 32.2834 16.894 32.2313 16.894 32.1375V32.1396Z"
                            fill="#232323"
                        />
                        <defs>
                            <linearGradient
                            id="paint0_linear_53_10115"
                            x1="2.23416"
                            y1="20.3361"
                            x2="26.863"
                            y2="44.9649"
                            gradientUnits="userSpaceOnUse"
                            >
                            <stop stopColor="#007EF8" />
                            <stop offset={1} stopColor="#FF4A9A" />
                            </linearGradient>
                        </defs>
                        </svg>
                    </span>
                    <button className="inline-block w-8">
                        <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth="1.5"
                        stroke="currentColor"
                        aria-hidden="true"
                        >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                        </svg>
                    </button>
                    </div>
                    <ul className="my-4 flex w-full flex-wrap gap-2 px-4 sm:hidden">
                    <Link to={"/liked-videos"}>
                        <li className="w-full">
                        <button className="flex w-full items-center justify-start gap-x-4 border border-white px-4 py-1.5 text-left hover:bg-[#ae7aff] hover:text-black focus:border-[#ae7aff] focus:bg-[#ae7aff] focus:text-black">
                            <span className="inline-block w-full max-w-[20px] group-hover:mr-4 lg:mr-4">
                            <svg
                                style={{ width: "100%" }}
                                viewBox="0 0 22 22"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                d="M6 21V10M1 12V19C1 20.1046 1.89543 21 3 21H16.4262C17.907 21 19.1662 19.9197 19.3914 18.4562L20.4683 11.4562C20.7479 9.6389 19.3418 8 17.5032 8H14C13.4477 8 13 7.55228 13 7V3.46584C13 2.10399 11.896 1 10.5342 1C10.2093 1 9.91498 1.1913 9.78306 1.48812L6.26394 9.40614C6.10344 9.76727 5.74532 10 5.35013 10H3C1.89543 10 1 10.8954 1 12Z"
                                stroke="currentColor"
                                strokeWidth={2}
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                />
                            </svg>
                            </span>
                            <span>Liked Videos</span>
                        </button>
                        </li>
                    </Link>
                    <Link to={`/content/${username}`}>
                        <li className="w-full">
                        <button className="flex w-full items-center justify-start gap-x-4 border border-white px-4 py-1.5 text-left hover:bg-[#ae7aff] hover:text-black focus:border-[#ae7aff] focus:bg-[#ae7aff] focus:text-black">
                            <span className="inline-block w-full max-w-[20px] group-hover:mr-4 lg:mr-4">
                            <svg
                                style={{ width: "100%" }}
                                viewBox="0 0 22 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                d="M21 4.93137C21 4.32555 21 4.02265 20.8802 3.88238C20.7763 3.76068 20.6203 3.69609 20.4608 3.70865C20.2769 3.72312 20.0627 3.93731 19.6343 4.36569L16 8L19.6343 11.6343C20.0627 12.0627 20.2769 12.2769 20.4608 12.2914C20.6203 12.3039 20.7763 12.2393 20.8802 12.1176C21 11.9774 21 11.6744 21 11.0686V4.93137Z"
                                stroke="currentColor"
                                strokeWidth={2}
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                />
                                <path
                                d="M1 5.8C1 4.11984 1 3.27976 1.32698 2.63803C1.6146 2.07354 2.07354 1.6146 2.63803 1.32698C3.27976 1 4.11984 1 5.8 1H11.2C12.8802 1 13.7202 1 14.362 1.32698C14.9265 1.6146 15.3854 2.07354 15.673 2.63803C16 3.27976 16 4.11984 16 5.8V10.2C16 11.8802 16 12.7202 15.673 13.362C15.3854 13.9265 14.9265 14.3854 14.362 14.673C13.7202 15 12.8802 15 11.2 15H5.8C4.11984 15 3.27976 15 2.63803 14.673C2.07354 14.3854 1.6146 13.9265 1.32698 13.362C1 12.7202 1 11.8802 1 10.2V5.8Z"
                                stroke="currentColor"
                                strokeWidth={2}
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                />
                            </svg>
                            </span>
                            <span>My Content</span>
                        </button>
                        </li>
                    </Link>
                    <li className="w-full">
                        <button className="flex w-full items-center justify-start gap-x-4 border border-white px-4 py-1.5 text-left hover:bg-[#ae7aff] hover:text-black focus:border-[#ae7aff] focus:bg-[#ae7aff] focus:text-black">
                        <span className="inline-block w-full max-w-[20px] group-hover:mr-4 lg:mr-4">
                            <svg
                            style={{ width: "100%" }}
                            viewBox="0 0 22 22"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            >
                            <path
                                d="M8.09 8C8.3251 7.33167 8.78915 6.76811 9.39995 6.40913C10.0108 6.05016 10.7289 5.91894 11.4272 6.03871C12.1255 6.15849 12.7588 6.52152 13.2151 7.06353C13.6713 7.60553 13.9211 8.29152 13.92 9C13.92 11 10.92 12 10.92 12M11 16H11.01M21 11C21 16.5228 16.5228 21 11 21C5.47715 21 1 16.5228 1 11C1 5.47715 5.47715 1 11 1C16.5228 1 21 5.47715 21 11Z"
                                stroke="currentColor"
                                strokeWidth={2}
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                            </svg>
                        </span>
                        <span>Support</span>
                        </button>
                    </li>
                    <li className="w-full">
                        <button className="flex w-full items-center justify-start gap-x-4 border border-white px-4 py-1.5 text-left hover:bg-[#ae7aff] hover:text-black focus:border-[#ae7aff] focus:bg-[#ae7aff] focus:text-black">
                        <span className="inline-block w-full max-w-[20px] group-hover:mr-4 lg:mr-4">
                            <svg
                            style={{ width: "100%" }}
                            viewBox="0 0 22 22"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            >
                            <path
                                d="M11 14C12.6569 14 14 12.6569 14 11C14 9.34315 12.6569 8 11 8C9.34315 8 8 9.34315 8 11C8 12.6569 9.34315 14 11 14Z"
                                stroke="currentColor"
                                strokeWidth={2}
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                            <path
                                d="M17.7273 13.7273C17.6063 14.0015 17.5702 14.3056 17.6236 14.6005C17.6771 14.8954 17.8177 15.1676 18.0273 15.3818L18.0818 15.4364C18.2509 15.6052 18.385 15.8057 18.4765 16.0265C18.568 16.2472 18.6151 16.4838 18.6151 16.7227C18.6151 16.9617 18.568 17.1983 18.4765 17.419C18.385 17.6397 18.2509 17.8402 18.0818 18.0091C17.913 18.1781 17.7124 18.3122 17.4917 18.4037C17.271 18.4952 17.0344 18.5423 16.7955 18.5423C16.5565 18.5423 16.3199 18.4952 16.0992 18.4037C15.8785 18.3122 15.678 18.1781 15.5091 18.0091L15.4545 17.9545C15.2403 17.745 14.9682 17.6044 14.6733 17.5509C14.3784 17.4974 14.0742 17.5335 13.8 17.6545C13.5311 17.7698 13.3018 17.9611 13.1403 18.205C12.9788 18.4489 12.8921 18.7347 12.8909 19.0273V19.1818C12.8909 19.664 12.6994 20.1265 12.3584 20.4675C12.0174 20.8084 11.5549 21 11.0727 21C10.5905 21 10.1281 20.8084 9.78708 20.4675C9.4461 20.1265 9.25455 19.664 9.25455 19.1818V19.1C9.24751 18.7991 9.15011 18.5073 8.97501 18.2625C8.79991 18.0176 8.55521 17.8312 8.27273 17.7273C7.99853 17.6063 7.69437 17.5702 7.39947 17.6236C7.10456 17.6771 6.83244 17.8177 6.61818 18.0273L6.56364 18.0818C6.39478 18.2509 6.19425 18.385 5.97353 18.4765C5.7528 18.568 5.51621 18.6151 5.27727 18.6151C5.03834 18.6151 4.80174 18.568 4.58102 18.4765C4.36029 18.385 4.15977 18.2509 3.99091 18.0818C3.82186 17.913 3.68775 17.7124 3.59626 17.4917C3.50476 17.271 3.45766 17.0344 3.45766 16.7955C3.45766 16.5565 3.50476 16.3199 3.59626 16.0992C3.68775 15.8785 3.82186 15.678 3.99091 15.5091L4.04545 15.4545C4.25503 15.2403 4.39562 14.9682 4.4491 14.6733C4.50257 14.3784 4.46647 14.0742 4.34545 13.8C4.23022 13.5311 4.03887 13.3018 3.79497 13.1403C3.55107 12.9788 3.26526 12.8921 2.97273 12.8909H2.81818C2.33597 12.8909 1.87351 12.6994 1.53253 12.3584C1.19156 12.0174 1 11.5549 1 11.0727C1 10.5905 1.19156 10.1281 1.53253 9.78708C1.87351 9.4461 2.33597 9.25455 2.81818 9.25455H2.9C3.2009 9.24751 3.49273 9.15011 3.73754 8.97501C3.98236 8.79991 4.16883 8.55521 4.27273 8.27273C4.39374 7.99853 4.42984 7.69437 4.37637 7.39947C4.3229 7.10456 4.18231 6.83244 3.97273 6.61818L3.91818 6.56364C3.74913 6.39478 3.61503 6.19425 3.52353 5.97353C3.43203 5.7528 3.38493 5.51621 3.38493 5.27727C3.38493 5.03834 3.43203 4.80174 3.52353 4.58102C3.61503 4.36029 3.74913 4.15977 3.91818 3.99091C4.08704 3.82186 4.28757 3.68775 4.50829 3.59626C4.72901 3.50476 4.96561 3.45766 5.20455 3.45766C5.44348 3.45766 5.68008 3.50476 5.9008 3.59626C6.12152 3.68775 6.32205 3.82186 6.49091 3.99091L6.54545 4.04545C6.75971 4.25503 7.03183 4.39562 7.32674 4.4491C7.62164 4.50257 7.9258 4.46647 8.2 4.34545H8.27273C8.54161 4.23022 8.77093 4.03887 8.93245 3.79497C9.09397 3.55107 9.18065 3.26526 9.18182 2.97273V2.81818C9.18182 2.33597 9.37338 1.87351 9.71435 1.53253C10.0553 1.19156 10.5178 1 11 1C11.4822 1 11.9447 1.19156 12.2856 1.53253C12.6266 1.87351 12.8182 2.33597 12.8182 2.81818V2.9C12.8193 3.19253 12.906 3.47834 13.0676 3.72224C13.2291 3.96614 13.4584 4.15749 13.7273 4.27273C14.0015 4.39374 14.3056 4.42984 14.6005 4.37637C14.8954 4.3229 15.1676 4.18231 15.3818 3.97273L15.4364 3.91818C15.6052 3.74913 15.8057 3.61503 16.0265 3.52353C16.2472 3.43203 16.4838 3.38493 16.7227 3.38493C16.9617 3.38493 17.1983 3.43203 17.419 3.52353C17.6397 3.61503 17.8402 3.74913 18.0091 3.91818C18.1781 4.08704 18.3122 4.28757 18.4037 4.50829C18.4952 4.72901 18.5423 4.96561 18.5423 5.20455C18.5423 5.44348 18.4952 5.68008 18.4037 5.9008C18.3122 6.12152 18.1781 6.32205 18.0091 6.49091L17.9545 6.54545C17.745 6.75971 17.6044 7.03183 17.5509 7.32674C17.4974 7.62164 17.5335 7.9258 17.6545 8.2V8.27273C17.7698 8.54161 17.9611 8.77093 18.205 8.93245C18.4489 9.09397 18.7347 9.18065 19.0273 9.18182H19.1818C19.664 9.18182 20.1265 9.37338 20.4675 9.71435C20.8084 10.0553 21 10.5178 21 11C21 11.4822 20.8084 11.9447 20.4675 12.2856C20.1265 12.6266 19.664 12.8182 19.1818 12.8182H19.1C18.8075 12.8193 18.5217 12.906 18.2778 13.0676C18.0339 13.2291 17.8425 13.4584 17.7273 13.7273Z"
                                stroke="currentColor"
                                strokeWidth={2}
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                            </svg>
                        </span>
                        <span>Settings</span>
                        </button>
                    </li>
                    </ul>
                    <div className="mb-8 mt-auto flex w-full flex-wrap gap-4 px-4 sm:mb-0 sm:mt-0 sm:items-center sm:px-0">
                        {
                        !token ? 
                        (
                            <>
                            <Link to={"/login"}>
                                <button className="w-full bg-[#383737] px-3 py-2 hover:bg-[#4f4e4e] sm:w-auto sm:bg-transparent">
                                Log in
                                </button>
                            </Link>
                            <Link to={"/signup"}>
                                <button className="mr-1 w-full bg-[#ae7aff] px-3 py-2 text-center font-bold text-black shadow-[5px_5px_0px_0px_#4f4e4e] transition-all duration-150 ease-in-out active:translate-x-[5px] active:translate-y-[5px] active:shadow-[0px_0px_0px_0px_#4f4e4e] sm:w-auto">
                                Sign up
                                </button>
                            </Link>
                            </>
                        ) : 
                        (
                            <button onClick={handleLogout} className="w-full bg-[#ae7aff] px-3 py-2 text-center font-bold text-black cursor-pointer sm:w-auto">
                            Logout
                            </button>
                        )
                        }
                    </div>
                </div>
                </nav>
            </header>
            <div className="flex min-h-[calc(100vh-66px)] sm:min-h-[calc(100vh-82px)]">
                <div className="mx-auto flex w-full max-w-7xl flex-col gap-y-6 px-4 py-8">
                    <div className="flex flex-wrap justify-between gap-4">
                        <div className="block">
                            <h1 className="text-2xl text-gray-200 font-bold">Welcome Back, {fullName}</h1>
                            <p className="text-sm text-gray-300">
                            Seamless Video Management, Elevated Results.
                            </p>
                        </div>
                        <div className="block">
                            <button onClick={handleToggleModal} className="inline-flex items-center gap-x-2 bg-[#ae7aff] px-3 py-2 font-semibold text-black">
                                <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    strokeWidth={2}
                                    stroke="currentColor"
                                    aria-hidden="true"
                                    className="h-5 w-5"
                                >
                                    <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M12 4.5v15m7.5-7.5h-15"
                                    />
                                </svg>
                                Upload video
                            </button>
                        </div>
                    </div>
                    <DashBoardCard likes={channelStats.totalLikes} views={channelStats.totalViews} videos={channelStats.totalVideos} subscribers={channelStats.totalSubscribers} />
                    <DashBoardTable handleEditVideo={handleEditVideo} isToggling={isToggling} handleCheckboxToggle={handleCheckboxToggle} handleDeleteClick={handleDeleteClick} videos={channelVideos} />
                    {toggleModal && <DashBoardUploadVideoModal handleUploadVideo={handleUploadVideo} handleClose={handleCloseModal} /> }
                    {uploadingVideo && <DashBoardUploadingVideo videoSize={videoSize} handleCloseVideo={handleCloseVideo} name={videoName} uploaded={uploadingVideo} /> }
                    {editVideo && <DashBoardEditVideo handleSubmitEditVideo={handleSubmitEditVideo} handleClose={handleEditVideoClose} video={editVideoData} /> }
                </div>
            </div>
        </>
    )
}

export default Dashboard